# Login-Signup-Form

## Login Signup form switching on tab using Vanilla JavaScript

### These are initial styles for the form. You may change it however you like or follow the tutorial [here](https://www.youtube.com/watch?v=uMk5tYgs7jE)
